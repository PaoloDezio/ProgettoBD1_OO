--Inserisci aree tematiche
call crea_area_tematica('ITALIANO');
call crea_area_tematica('MATEMATICA');
call crea_area_tematica('STORIA');
call crea_area_tematica('GEOGRAFIA');
call crea_area_tematica('FILOSOFIA');
call crea_area_tematica('INFORMATICA');
call crea_area_tematica('PEDAGOGIA');
call crea_area_tematica('ELETTRONICA');
call crea_area_tematica('GIURISPRUDENZA');
call crea_area_tematica('LETTERE');

--Inserisco gli studenti
call registra_studente('PAOLO','DEZIO','MADDALONI','1998-06-24','AAAAAAAAAAAAAAAA');
call registra_studente('STEFANO','SABIA','NAPOLI','1997-12-07','AAAAAAAAAAAAAAAB');
call registra_studente('MARIA','CASTALDO','MILANO','2000-12-25','AAAAAAAAAAAAAAAC');
call registra_studente('MARIO','CASILLO','CASERTA','1997-01-09','AAAAAAAAAAAAAAAD');
call registra_studente('GIOVANNI','CIAMPA','GENOVA','1996-10-08','AAAAAAAAAAAAAAAE');
call registra_studente('ANGELO','LAEZZA','ANCONA','1995-10-07','AAAAAAAAAAAAAAAF');
call registra_studente('MAURIZIO','DI MASO','LORETO','1994-04-06','AAAAAAAAAAAAAAAG');
call registra_studente('FRANCESCA','ESPOSITO','AVERSA','1993-04-05','AAAAAAAAAAAAAAAH');
call registra_studente('GIOVANNA','REGA','AFRAGOLA','1992-04-04','AAAAAAAAAAAAAAAI');
call registra_studente('MIRIANA','RUSSO','FRATTAMAGGIORE','1991-05-03','AAAAAAAAAAAAAAAJ');
call registra_studente('VITTORIO','MANNA','ACERRA','1990-05-02','AAAAAAAAAAAAAAAK');
call registra_studente('FRANCESCO','SALIERNO','BENEVENTO','1998-05-01','AAAAAAAAAAAAAAAL');
call registra_studente('MIRIAM','MOSCA','SALERNO','1997-06-12','AAAAAAAAAAAAAAAM');
call registra_studente('PIERPAOLO','TUCCILLO','AVELLINO','1996-06-13','AAAAAAAAAAAAAAAN');
call registra_studente('FABIO','ESPOSITO','VOLLA','1995-06-14','AAAAAAAAAAAAAAAO');
call registra_studente('PAOLO','ESPOSITO','NOLA','1994-07-15','AAAAAAAAAAAAAAAP');
call registra_studente('MICHELE','GALEAZZI','MADDALONI','1993-07-16','AAAAAAAAAAAAAAAQ');
call registra_studente('GIUSEPPE','ZENOLI','MADDALONI','1992-07-17','AAAAAAAAAAAAAAAR');
call registra_studente('ANDREA','DI MICCO','NAPOLI','1991-08-18','AAAAAAAAAAAAAAAS');
call registra_studente('FAUSTO','BENINCASA','NAPOLI','1990-08-19','AAAAAAAAAAAAAAAT');
call registra_studente('GUGLIELMO','ROSSI','NAPOLI','1999-08-20','AAAAAAAAAAAAAAAU');
call registra_studente('ANNA','DI MEGLIO','NAPOLI','1998-09-21','AAAAAAAAAAAAAAAV');
call registra_studente('ANNALISA','LAEZZA','MILANO','1997-09-22','AAAAAAAAAAAAAAAW');
call registra_studente('FRANCESCALAURA','LAEZZA','MILANO','1994-09-23','AAAAAAAAAAAAAAAX');
call registra_studente('ENRICO','ESPOSITO','MILANO','1995-10-24','AAAAAAAAAAAAAAAY');
call registra_studente('PASQUALE','SORBILLO','MILANO','1996-10-25','AAAAAAAAAAAAAAAZ');
call registra_studente('DOMENICO','D ALISE','MILANO','1992-10-26','AAAAAAAAAAAAAAA0');
call registra_studente('MIRCO','D ANTO','MADDALONI','1992-11-27','AAAAAAAAAAAAAAA1');
call registra_studente('TOMMASO','D AMBROSIO','MADDALONI','1993-11-29','AAAAAAAAAAAAAAA2');
call registra_studente('MARCO','ABATE','MADDALONI','1991-11-28','AAAAAAAAAAAAAAA3');

--Inserisco i docenti
call registra_docente('MARIO','ROSSI','MADDALONI','1990-01-12','BBBBBBBBBBBBBBBB');
call registra_docente('NICOLA','VINCISCHELLI','NAPOLI','1989-02-13','BBBBBBBBBBBBBBBA');
call registra_docente('VINCENZO','TROMBETTI','POMPEI','1970-03-13','BBBBBBBBBBBBBBBC');
call registra_docente('GIOVANNI','MICCOLO','NOLA','1988-04-13','BBBBBBBBBBBBBBBD');
call registra_docente('GIOVANNA','FRANZESE','ERCOLANO','1978-04-14','BBBBBBBBBBBBBBBE');
call registra_docente('FEDERICA','GIOVANARDI','POZZUOLI','1972-05-15','BBBBBBBBBBBBBBBF');
call registra_docente('FRANCESCA','VERDE','AVERSA','1960-06-16','BBBBBBBBBBBBBBBG');
call registra_docente('MICHELA','CAPUOZZO','FRATTAMAGGIORE','1966-07-17','BBBBBBBBBBBBBBBH');
call registra_docente('GIADA','ESPOSITO','AFRAGOLA','1964-08-18','BBBBBBBBBBBBBBBI');
call registra_docente('ANDREA','MARIELLO','CARDITO','1966-09-19','BBBBBBBBBBBBBBBL');

--Inserisco i responsabili
call registra_responsabile('PAOLO','DEZIO','MADDALONI','1998-06-24','CCCCCCCCCCCCCCCA','admin','admin');
call registra_responsabile('STEFANO MARIA','SABIA','NAPOLI','1997-06-24','CCCCCCCCCCCCCCCB','ad','ad');
call registra_responsabile('PIPPO','PIPPO','PAPEROPOLI','1990-01-01','CCCCCCCCCCCCCCCC','pippo','pippo');
call registra_responsabile('PLUTO','PLUTO','PAPEROPOLI','1990-01-01','CCCCCCCCCCCCCCCD','pluto','pluto');

--Inserisco i corsi
call crea_corso('ANALISI MATEMATICA 1','STUDIO DI FUNZIONE, DOMINI, INTEGRALI E DERIVATE',50,24,'2022-06-29',1);
call crea_corso('DIRITTO PRIVATO','CONTRATTI E OBBLIGAZIONI',50,32,'2020-10-10',2);
call crea_corso('LABORATORIO DI PROGRAMMAZIONE','IL LINGUAGGIO C',100,12,'2021-11-11',3);
call crea_corso('BASI DI DATI 1','TABELLE VISTE E TRIGGER',100,15,'2009-04-15',4);
call crea_corso('OBJECT ORIENTATION','JAVA E WINDOW BUILDER',150,15,'2008-09-23',1);
call crea_corso('FISICA GENERALE 1','LEGGI DELLA DINAMICA',150,16,'2019-10-30',2);
call crea_corso('STORIA 1','L IMPERO ROMANO',175,18,'2018-02-02',3);
call crea_corso('ITALIANO 1','DANTE E LEOPARDI',175,19,'2018-02-02',4);
call crea_corso('CALCOLATORI ELETTRONICI','AND OR NOT E ALCUNI CIRCUITI',200,21,'2016-07-12',1);
call crea_corso('FISICA GENERALE 2','ELETTROMAGNETISMO',200,24,'2017-09-13',2);

--Popolo tematica_corso
call associa_categorie(1,'MATEMATICA');
call associa_categorie(2,'GIURISPRUDENZA');
call associa_categorie(3,'INFORMATICA');
call associa_categorie(4,'INFORMATICA');
call associa_categorie(5,'INFORMATICA');
call associa_categorie(6,'MATEMATICA');
call associa_categorie(7,'STORIA,GEOGRAFIA');
call associa_categorie(8,'ITALIANO,LETTERE');
call associa_categorie(9,'ELETTRONICA,INFORMATICA');
call associa_categorie(10,'MATEMATICA');

--Popolo iscrivere
call iscrivi_studente(2,1);
call iscrivi_studente(3,2);
call iscrivi_studente(4,3);
call iscrivi_studente(5,4);
call iscrivi_studente(6,5);
call iscrivi_studente(7,6);
call iscrivi_studente(8,7);
call iscrivi_studente(9,8);
call iscrivi_studente(10,9);
call iscrivi_studente(1,10);
call iscrivi_studente(2,11);
call iscrivi_studente(3,12);
call iscrivi_studente(4,13);
call iscrivi_studente(5,14);
call iscrivi_studente(6,15);
call iscrivi_studente(7,16);
call iscrivi_studente(8,17);
call iscrivi_studente(9,18);
call iscrivi_studente(10,19);
call iscrivi_studente(1,20);
call iscrivi_studente(2,21);
call iscrivi_studente(3,22);
call iscrivi_studente(4,23);
call iscrivi_studente(5,24);
call iscrivi_studente(6,25);
call iscrivi_studente(7,26);
call iscrivi_studente(8,27);
call iscrivi_studente(9,28);
call iscrivi_studente(10,29);
call iscrivi_studente(1,30);
call iscrivi_studente(2,2);
call iscrivi_studente(3,3);
call iscrivi_studente(4,4);
call iscrivi_studente(5,5);
call iscrivi_studente(6,6);
call iscrivi_studente(7,7);
call iscrivi_studente(8,8);
call iscrivi_studente(9,9);
call iscrivi_studente(10,10);
call iscrivi_studente(1,11);
call iscrivi_studente(2,12);
call iscrivi_studente(3,13);
call iscrivi_studente(4,14);
call iscrivi_studente(5,15);
call iscrivi_studente(6,16);
call iscrivi_studente(7,17);
call iscrivi_studente(8,18);
call iscrivi_studente(9,19);
call iscrivi_studente(10,20);
call iscrivi_studente(1,21);
call iscrivi_studente(2,22);
call iscrivi_studente(3,23);
call iscrivi_studente(4,24);
call iscrivi_studente(5,25);
call iscrivi_studente(6,26);
call iscrivi_studente(7,27);
call iscrivi_studente(8,28);
call iscrivi_studente(9,29);
call iscrivi_studente(10,30);
call iscrivi_studente(1,3);

--Inserisco le lezioni
call crea_lezione('LEZIONE 1','INTRODUZIONE','2:00:00','2022-06-29 15:30',1,1,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 2','DOMINI','2:00:00','2022-06-30 15:30',1,1,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 3','INTEGRALI','2:00:00','2022-07-01 15:30',1,1,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 4','STUDIO DI FUNZIONE','2:00:00','2022-07-02 15:30',1,1,'TRUE','A4','MSA','TEAMS');
call crea_lezione('LEZIONE 5','FUNZIONI INIETTIVE','2:00:00','2022-07-03 15:30',1,1,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 6','FUNZIONI SURIETTIVE','2:00:00','2022-07-04 15:30',1,1,'TRUE','A4','MSA','TEAMS');
call crea_lezione('LEZIONE 7','FUNZIONI BIIETTIVE','2:00:00','2022-07-05 15:30',1,1,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 8','SERIE','2:00:00','2022-07-06 15:30',1,1,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 9','CONVERGENZA','2:00:00','2022-07-07 15:30',1,1,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 10','INTEGRALI PER PARTI','2:00:00','2022-07-08 15:30',1,1,'TRUE','A4','MSA','TEAMS');

call crea_lezione('LEZIONE 1','INTRODUZIONE','2:00:00','2020-10-10 14:30',2,2,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 2','OBBLIGAZIONI','1:00:00','2020-10-11 14:30',2,2,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 3','CONTRATTI','1:30:00','2020-10-12 14:30',2,2,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 4','COSTITUZIONE','2:00:00','2020-10-13 14:30',2,2,'TRUE','A4','MSA','TEAMS');
call crea_lezione('LEZIONE 5','LE PENE','2:00:00','2020-10-14 14:30',2,2,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 6','I PROCESSI','3:00:00','2020-10-15 14:30',2,2,'TRUE','A4','MSA','TEAMS');
call crea_lezione('LEZIONE 7','LEGGI DEL DIRITTO PRIVATO','2:00:00','2020-10-16 14:30',2,2,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 8','ARTICOLI','1:00:00','2020-10-17 14:30',2,2,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 9','BUROCRAZIA','2:00:00','2020-10-18 14:30',2,2,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 10','PROVA D ESAME','2:00:00','2020-10-19 14:30',2,2,'TRUE','A4','MSA','TEAMS');

call crea_lezione('LEZIONE 1','INTRODUZIONE','1:00:00','2021-11-11 14:00',3,3,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 2','FOR','1:00:00','2021-11-12 14:00',3,3,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 3','WHILE','1:00:00','2021-11-13 14:00',3,3,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 4','IF','1:00:00','2021-11-14 14:00',3,3,'TRUE','A4','MSA','TEAMS');
call crea_lezione('LEZIONE 5','ELSE','1:00:00','2021-11-15 14:00',3,3,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 6','DO WHILE','1:00:00','2021-11-16 14:00',3,3,'TRUE','A4','MSA','TEAMS');
call crea_lezione('LEZIONE 7','SWITCH CASE','1:00:00','2021-11-17 14:00',3,3,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 8','LINKED LIST','1:00:00','2021-11-18 14:00',3,3,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 9','STRUCT','1:00:00','2021-11-19 14:00',3,3,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 10','PROVA D ESAME','1:00:00','2021-11-20 14:00',3,3,'TRUE','A4','MSA','TEAMS');

call crea_lezione('LEZIONE 1','INTRODUZIONE','2:00:00','2009-04-15 10:00',4,4,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 2','TABELLE','2:00:00','2009-04-16 10:00',4,4,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 3','VISTE','2:00:00','2009-04-17 10:00',4,4,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 4','TRIGGER','2:00:00','2009-04-18 10:00',4,4,'TRUE','A4','MSA','TEAMS');
call crea_lezione('LEZIONE 5','FUNZIONI','2:00:00','2009-04-19 10:00',4,4,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 6','CLASS DIAGRAMM','2:00:00','2009-04-20 10:00',4,4,'TRUE','A4','MSA','TEAMS');
call crea_lezione('LEZIONE 7','CLASS DIAGRAMM RISTRUTTURATO','2:00:00','2009-04-21 10:00',4,4,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 8','DOMINI','2:00:00','2009-04-22 10:00',4,4,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 9','VINCOLI','2:00:00','2009-04-23 10:00',4,4,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 10','PROVA D ESAME','2:00:00','2009-04-24 10:00',4,4,'TRUE','A4','MSA','TEAMS');

call crea_lezione('LEZIONE 1','INTRODUZIONE','2:00:00','2008-09-23 11:00',5,5,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 2','STORIA DI JAVA','2:00:00','2008-09-24 11:00',5,5,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 3','STRINGHE','2:00:00','2008-09-25 11:00',5,5,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 4','VETTORI','2:00:00','2008-09-26 11:00',5,5,'TRUE','A4','MSA','TEAMS');
call crea_lezione('LEZIONE 5','ARRAYLIST','2:00:00','2008-09-27 11:00',5,5,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 6','SQUENCE DIAGRAM','2:00:00','2008-09-28 11:00',5,5,'TRUE','A4','MSA','TEAMS');
call crea_lezione('LEZIONE 7','ABSTRACT','2:00:00','2008-09-29 11:00',5,5,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 8','INTERFACE','2:00:00','2008-09-30 11:00',5,5,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 9','WINDOW BUILDER','2:00:00','2008-10-01 11:00',5,5,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 10','PROVA D ESAME','2:00:00','2008-10-02 11:00',5,5,'TRUE','A4','MSA','TEAMS');


call crea_lezione('LEZIONE 1','INTRODUZIONE','2:00:00','2019-10-30 11:00',6,6,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 2','DINAMICA','2:00:00','2019-10-31 11:00',6,6,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 3','TERMODINAMICA','2:00:00','2019-11-01 11:00',6,6,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 4','RENDIMENTO','2:00:00','2019-11-02 11:00',6,6,'TRUE','A4','MSA','TEAMS');
call crea_lezione('LEZIONE 5','IMPULSO','2:00:00','2019-11-03 11:00',6,6,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 6','LEGGE DI ATTRAZIONE GRAVITAZIONALE','2:00:00','2019-11-04 11:00',6,6,'TRUE','A4','MSA','TEAMS');
call crea_lezione('LEZIONE 7','LEVE','2:00:00','2019-11-05 11:00',6,6,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 8','QUANTITA DI MOTO','2:00:00','2019-11-06 11:00',6,6,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 9','LEGGI DI GAUSS','2:00:00','2019-11-07 11:00',6,6,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 10','PROVA D ESAME','2:00:00','2019-11-08 11:00',6,6,'TRUE','A4','MSA','TEAMS');

call crea_lezione('LEZIONE 1','INTRODUZIONE','2:00:00','2018-02-02 07:00',7,7,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 2','GIULIO CESARE','2:00:00','2018-02-03 07:00',7,7,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 3','CATILINA','2:00:00','2018-02-04 07:00',7,7,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 4','CICERONE','2:00:00','2018-02-05 07:00',7,7,'TRUE','A4','MSA','TEAMS');
call crea_lezione('LEZIONE 5','GRACCHI','2:00:00','2018-02-06 07:00',7,7,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 6','MONARCHIA','2:00:00','2018-02-07 07:00',7,7,'TRUE','A4','MSA','TEAMS');
call crea_lezione('LEZIONE 7','GIULIO CLAUDIO','2:00:00','2018-02-08 07:00',7,7,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 8','CRISI DEL TERZO SECOLO','2:00:00','2018-02-09 07:00',7,7,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 9','LA CADUTA','2:00:00','2018-02-10 07:00',7,7,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 10','PROVA D ESAME','2:00:00','2018-02-11 07:00',7,7,'TRUE','A4','MSA','TEAMS');

call crea_lezione('LEZIONE 1','INTRODUZIONE','2:00:00','2018-02-02 08:00',8,8,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 2','DANTE','2:00:00','2018-02-03 08:00',8,8,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 3','LEOPARDI','2:00:00','2018-02-04 08:00',8,8,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 4','PETRARCA','2:00:00','2018-02-05 08:00',8,8,'TRUE','A4','MSA','TEAMS');
call crea_lezione('LEZIONE 5','BOCCACCIO','2:00:00','2018-02-06 08:00',8,8,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 6','MACHIAVELLI','2:00:00','2018-02-07 08:00',8,8,'TRUE','A4','MSA','TEAMS');
call crea_lezione('LEZIONE 7','DARIO FO','2:00:00','2018-02-08 08:00',8,8,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 8','MONTALE','2:00:00','2018-02-09 08:00',8,8,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 9','UGO FOSCOLO','2:00:00','2018-02-10 08:00',8,8,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 10','PROVA D ESAME','2:00:00','2018-02-11 08:00',8,8,'TRUE','A4','MSA','TEAMS');

call crea_lezione('LEZIONE 1','INTRODUZIONE','2:00:00','2016-07-12 08:00',9,9,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 2','AND','2:00:00','2016-07-13 08:00',9,9,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 3','OR','2:00:00','2016-07-14 08:00',9,9,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 4','NOT','2:00:00','2016-07-15 08:00',9,9,'TRUE','A4','MSA','TEAMS');
call crea_lezione('LEZIONE 5','XOR','2:00:00','2016-07-16 08:00',9,9,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 6','CALCOLATORI','2:00:00','2016-07-17 08:00',9,9,'TRUE','A4','MSA','TEAMS');
call crea_lezione('LEZIONE 7','DECODER','2:00:00','2016-07-18 08:00',9,9,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 8','ENCODER','2:00:00','2016-07-19 08:00',9,9,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 9','TRANSISTOR','2:00:00','2016-07-20 08:00',9,9,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 10','PROVA D ESAME','2:00:00','2016-07-21 08:00',9,9,'TRUE','A4','MSA','TEAMS');

call crea_lezione('LEZIONE 1','INTRODUZIONE','2:00:00','2017-09-13 08:00',10,10,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 2','ELETTROMAGNETISMO','2:00:00','2017-09-14 08:00',10,10,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 3','CONDENSATORI','2:00:00','2017-09-15 08:00',10,10,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 4','CICLO DI ISTERESI','2:00:00','2017-09-16 08:00',10,10,'TRUE','A4','MSA','TEAMS');
call crea_lezione('LEZIONE 5','CIRCUITI IN SERIE','2:00:00','2017-09-17 08:00',10,10,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 6','CIRCUITI IN PARALLELO','2:00:00','2017-09-18 08:00',10,10,'TRUE','A4','MSA','TEAMS');
call crea_lezione('LEZIONE 7','RESISTENZE','2:00:00','2017-09-19 08:00',10,10,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 8','DIODI','2:00:00','2017-09-20 08:00',10,10,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 9','GAUSS','2:00:00','2017-09-21 08:00',10,10,'FALSE','A4','MSA',NULL);
call crea_lezione('LEZIONE 10','PROVA D ESAME','2:00:00','2017-09-22 08:00',10,10,'TRUE','A4','MSA','TEAMS');

--Popolo partecipare
call registra_partecipazione(1,1);
call registra_partecipazione(1,3);
call registra_partecipazione(1,4);
call registra_partecipazione(1,5);
call registra_partecipazione(1,6);
call registra_partecipazione(1,7);
call registra_partecipazione(1,8);
call registra_partecipazione(1,9);

call registra_partecipazione(2,10);
call registra_partecipazione(2,3);
call registra_partecipazione(2,4);
call registra_partecipazione(2,5);
call registra_partecipazione(2,6);
call registra_partecipazione(2,7);
call registra_partecipazione(2,8);
call registra_partecipazione(2,9);
call registra_partecipazione(2,12);
call registra_partecipazione(2,14);
call registra_partecipazione(2,15);
call registra_partecipazione(2,16);

call registra_partecipazione(4,22);
call registra_partecipazione(4,23);
call registra_partecipazione(4,24);
call registra_partecipazione(4,25);
call registra_partecipazione(4,26);
call registra_partecipazione(4,27);
call registra_partecipazione(4,28);
call registra_partecipazione(4,32);
call registra_partecipazione(4,34);
call registra_partecipazione(4,36);
call registra_partecipazione(4,38);

call registra_partecipazione(5,32);
call registra_partecipazione(5,34);
call registra_partecipazione(5,36);
call registra_partecipazione(5,38);
call registra_partecipazione(5,42);

call registra_partecipazione(6,52);
call registra_partecipazione(6,53);
call registra_partecipazione(6,54);
call registra_partecipazione(6,55);
call registra_partecipazione(6,56);
call registra_partecipazione(6,57);
call registra_partecipazione(6,58);
call registra_partecipazione(6,59);
call registra_partecipazione(6,60);
call registra_partecipazione(6,61);
call registra_partecipazione(6,62);
call registra_partecipazione(6,63);
call registra_partecipazione(6,64);
call registra_partecipazione(6,65);
call registra_partecipazione(6,66);
call registra_partecipazione(6,67);
call registra_partecipazione(6,68);
call registra_partecipazione(6,69);
call registra_partecipazione(6,70);
call registra_partecipazione(6,71);







