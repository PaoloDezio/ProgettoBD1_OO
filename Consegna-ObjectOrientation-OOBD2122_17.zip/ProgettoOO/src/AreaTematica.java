
public class AreaTematica {
	
	private String categoria;

	//GETTERS AND SETTERS
	public String getCategoria() {
		return categoria;
	}
	
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	
	
}
