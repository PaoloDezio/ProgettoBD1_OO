
public class Studente extends Utente {
	
	private Integer codiceStudente;
	
	//GETTERS AND SETTERS
	public Integer getCodiceStudente() {
		return codiceStudente;
	}
	
	public void setCodiceStudente(Integer codiceStudente) {
		this.codiceStudente = codiceStudente;
	}
	
	
	
}
