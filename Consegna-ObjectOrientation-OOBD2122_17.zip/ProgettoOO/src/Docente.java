
public class Docente extends Utente {
	
	private Integer codiceDocente;
	
	//GETTERS AND SETTERS
	public Integer getCodiceDocente() {
		return codiceDocente;
	}
	
	public void setCodiceDocente(Integer codiceDocente) {
		this.codiceDocente = codiceDocente;
	}
	
	
	
}
